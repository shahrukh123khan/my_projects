from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base,sessionmaker

DATABASE_URL =(
    "postgresql+psycopg2://fastapi_user:FastAPI%4012345@localhost:5432/student"
)

engine = create_engine(DATABASE_URL,pool_pre_ping=True)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# example to understand how db = SessionLocal() works 
# Just kidding
# class Student:
#     def __init__(self, name):
#         self.name = name


# def create_student_class():
#     return Student


# StudentClass = create_student_class()  # Returns the class

# student = StudentClass("Rahul")        # Creates an object

# print(student.name)  # Rahul

# revision --autogenerate = Django's makemigrations
# upgrade head = Django's migrate
# alembic revision --autogenerate -m "create students table"
# alembic upgrade heads
#uvicorn main:app --reload





