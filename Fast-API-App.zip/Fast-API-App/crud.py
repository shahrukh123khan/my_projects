
from sqlalchemy.orm import Session
from sqlalchemy import select
from models import Student
from schemas import StudentCreate, StudentUpdate

def create_student(db:Session,student_create:StudentCreate):
    student =Student(**student_create.model_dump())

    db.add(student)
    db.commit()
    db.refresh(student)
    return student

def get_students(db: Session):
    # statement = select(Student).order_by(Student.id)
    students = db.query(Student).all()
    return students


def get_student(db: Session, student_id: int):
    return db.get(Student, student_id)


def update_student(
    db: Session,
    student: Student,
    student_data: StudentUpdate
):
    update_data = student_data.model_dump(exclude_unset=True)

    for field, value in update_data.items():
        setattr(student, field, value)

    db.commit()
    db.refresh(student)

    return student


def delete_student(db: Session, student: Student):
    db.delete(student)
    db.commit()