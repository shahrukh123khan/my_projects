from pydantic import BaseModel, ConfigDict, Field
from typing import Optional


class StudentCreate(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    email: str = Field(min_length=1, max_length=150)
    age: int = Field(gt=0, le=120)

class StudentUpdate(BaseModel):
    name: str | None = Field(default=None, max_length=100)
    email: str | None = Field(default=None, max_length=150)
    age: int | None = Field(default=None, gt=0, le=120)


class StudentResponse(BaseModel):
    id: int
    name: str
    email: str
    age: int

    model_config = ConfigDict(from_attributes=True)